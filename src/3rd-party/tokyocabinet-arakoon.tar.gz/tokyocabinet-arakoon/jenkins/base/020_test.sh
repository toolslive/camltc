#!/bin/bash -xue

make check
