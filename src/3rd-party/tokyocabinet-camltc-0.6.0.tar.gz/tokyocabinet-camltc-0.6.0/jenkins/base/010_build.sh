#!/bin/bash -xue

./configure --disable-bzip --disable-zlib
make
